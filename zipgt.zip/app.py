import streamlit as st
from experiments import dynamic_experiment

# Configure page settings
st.set_page_config(
    page_title="Graph Theory Lab Record",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS to enforce clean white academic style
st.markdown("""
    <style>
    .stApp {
        background-color: #FFFFFF;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
    }
    .stTabs [data-baseweb="tab"] {
        padding-top: 10px;
        padding-bottom: 10px;
        padding-left: 20px;
        padding-right: 20px;
        border-radius: 4px 4px 0 0;
    }
    </style>
""", unsafe_allow_html=True)

# Sidebar setup
st.sidebar.title("Graph Theory Laboratory")

st.sidebar.header("Student Information")
name = st.sidebar.text_input("Name", placeholder="Enter your name")
roll = st.sidebar.text_input("Roll Number", placeholder="Enter roll number")
subject = st.sidebar.text_input("Subject", value="Graph Theory")
semester = st.sidebar.text_input("Semester", placeholder="e.g., 4th")
date = st.sidebar.date_input("Date")

st.sidebar.markdown("---")

# Navigation
st.sidebar.header("Experiments")

EXPERIMENT_LIST = [
    "1 Basic Graphs",
    "2 Graph Isomorphism",
    "3 Subgraphs",
    "4 Havel-Hakimi",
    "5 Line Graph",
    "6 Kruskal MST",
    "7 Dijkstra",
    "8 Closed Walks Trails Paths",
    "9 Eulerian Circuit",
    "10 Hamiltonian Circuit",
    "11 Greedy Graph Colouring"
]

experiment_selection = st.sidebar.radio(
    "Select an Experiment to view:",
    EXPERIMENT_LIST
)

# Dynamic loading of experiment pages
dynamic_experiment.render(experiment_selection)

