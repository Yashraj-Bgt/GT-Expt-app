import streamlit as st
import importlib
import contextlib
import io
import matplotlib.pyplot as plt
import os

EXPERIMENT_MAP = {
    "1 Basic Graphs": "exp1",
    "2 Graph Isomorphism": "exp2",
    "3 Subgraphs": "exp3",
    "4 Havel-Hakimi": "exp4",
    "5 Line Graph": "exp5",
    "6 Kruskal MST": "exp6",
    "7 Dijkstra": "exp7",
    "8 Closed Walks Trails Paths": "exp8",
    "9 Eulerian Circuit": "exp9",
    "10 Hamiltonian Circuit": "exp10",
    "11 Greedy Graph Colouring": "exp11"
}

def mock_show(*args, **kwargs):
    """Intercepts plt.show() and natively renders the plot in Streamlit."""
    st.pyplot(plt.gcf())
    plt.clf()

def render(experiment_name):
    st.title("Graph Theory Laboratory")
    st.header(experiment_name)
    
    exp_id = EXPERIMENT_MAP.get(experiment_name)
    if not exp_id:
        st.error("Experiment not found mapping.")
        return

    # Tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["Theory", "Algorithm", "Code", "Run Experiment", "Output"])
    
    with tab1:
        st.markdown("### Theory")
        st.info("Theory section from the Virtual Record framework.")
        
    with tab2:
        st.markdown("### Algorithm")
        st.info("Algorithm step-by-step framework.")
        
    with tab3:
        st.markdown("### Source Code")
        file_path = os.path.join("lab_experiments", f"{exp_id}.py")
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                code_content = f.read()
            st.code(code_content, language='python')
        else:
            st.error(f"Source file not found: {file_path}")
            
    with tab4:
        st.markdown("### Run Experiment")
        st.write("Click below to execute the underlying lab experiment script.")
        if st.button("Execute Experiment", type="primary"):
            st.session_state[f'run_{exp_id}'] = True
            
    with tab5:
        st.markdown("### Output")
        if st.session_state.get(f'run_{exp_id}'):
            with st.spinner("Executing..."):
                # Intercept stdout and plt.show
                original_show = plt.show
                plt.show = mock_show
                f_out = io.StringIO()
                
                try:
                    with contextlib.redirect_stdout(f_out):
                        # Dynamically import the module
                        module = importlib.import_module(f"lab_experiments.{exp_id}")
                        # Reload it to ensure clean state if run multiple times
                        importlib.reload(module)
                        
                        if hasattr(module, "run"):
                            module.run()
                        else:
                            st.warning("No 'run()' function found in the module.")
                except Exception as e:
                    st.error(f"Execution Error: {e}")
                finally:
                    # Restore plt.show
                    plt.show = original_show
                
                # Render captured text output
                text_output = f_out.getvalue()
                if text_output.strip():
                    st.markdown("**Console Output:**")
                    st.code(text_output, language='text')
                
                st.success("Execution completed.")
        else:
            st.info("Run the experiment to view the captured output and figures.")
